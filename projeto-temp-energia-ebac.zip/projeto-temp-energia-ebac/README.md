# Relação entre Temperatura e Consumo de Energia

Projeto didático (EBAC) para investigar como a **temperatura** se relaciona com o **consumo de energia elétrica** nas cidades de **São Paulo**, **Rio de Janeiro** e **Belo Horizonte**.

## 🎯 Objetivo
Explorar e modelar a relação entre temperatura e consumo de energia, calculando correlações e ajustando uma **regressão linear** para São Paulo. O projeto serve como base para evoluir depois para modelos de séries temporais.

## 🗂️ Estrutura
```
projeto-temp-energia-ebac/
├── data/                 # CSVs das cidades
├── notebooks/            # Notebooks Jupyter/Colab
├── outputs/              # Gráficos e tabelas exportados
├── src/                  # (opcional) scripts auxiliares
├── requirements.txt      # Dependências Python
├── README.md
└── .gitignore
```

## 🧪 Dados
Arquivos CSV no diretório `data/` com as colunas:
- `data` (YYYY-MM-DD)
- `temperatura` (°C)
- `consumo_kwh` (kWh)

Arquivos de exemplo já inclusos: `sp.csv`, `rj.csv`, `bh.csv` (amostras sintéticas).

> **Dica**: Se seus arquivos estiverem com separador `;` e decimais com vírgula, use `sep=";"` e `decimal=","` ao ler com `pandas.read_csv`.

## ❓ Perguntas de análise
1. Como evoluem temperatura e consumo ao longo do tempo em cada cidade?
2. Existe correlação entre as séries por cidade?
3. Qual a inclinação/força do ajuste de regressão linear entre temperatura e consumo para **São Paulo**?
4. O modelo simples é útil para previsão de curto prazo?

## ▶️ Como executar no Google Colab
1. Acesse colab.new e **faça upload** do notebook `notebooks/analise_temp_energia.ipynb` (ou abra direto do GitHub depois que subir).
2. Se quiser rodar localmente, instale as dependências: `pip install -r requirements.txt`.
3. No Colab, **faça upload** dos CSVs de `data/` pela barra lateral (ou monte o Google Drive) e ajuste o caminho dos arquivos, se necessário.
4. Execute as células na ordem. Os gráficos e tabelas podem ser exportados para `outputs/`.

## ⬆️ Como subir para o GitHub
### Opção A — pelo Colab (mais simples)
- Menu **Arquivo → Salvar uma cópia no GitHub**.
- Escolha o repositório (ex.: `seu-usuario/projeto-temp-energia-ebac`), o caminho (ex.: `notebooks/`) e escreva uma mensagem de commit.

### Opção B — via `git` no próprio Colab
1. Crie um repositório vazio no GitHub.
2. Gere um **Personal Access Token** (PAT) com permissão para `contents:write`.
3. No Colab, rode:
   ```bash
   !git config --global user.name "Seu Nome"
   !git config --global user.email "seu.email@example.com"

   repo="https://github.com/SEU_USUARIO/projeto-temp-energia-ebac.git"
   token="${GITHUB_TOKEN}"  # Dica: defina antes: os.environ["GITHUB_TOKEN"]

   !git clone $repo projeto-temp-energia-ebac-clone
   !rsync -av --exclude '.git' /content/projeto-temp-energia-ebac/ /content/projeto-temp-energia-ebac-clone/
   %cd /content/projeto-temp-energia-ebac-clone
   !git add .
   !git commit -m "Projeto inicial: dados + notebook + README"
   !git remote remove origin
   !git remote add origin https://${GITHUB_TOKEN}@github.com/SEU_USUARIO/projeto-temp-energia-ebac.git
   !git push -u origin main
   ```

> **Importante**: Nunca exponha seu token em notebooks públicos. Prefira `os.environ["GITHUB_TOKEN"]`.

## 👩🏽‍💻 Autor
Projeto educacional para o curso da **EBAC**.

---
Licença: MIT
